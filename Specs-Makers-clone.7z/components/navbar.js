function navbar (){
    return ` <div class=" fixed width100 top0 left0">
    <div id="menu2" class="width100 height63p colwhite bl1  ">
        <div class="width90 flex marauto jusspacebet">
            <a href="../index.html"><div class="mar7p point"><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/files/SPECSMAKERS_Logo_large.png?v=1610087240" alt=""></div></a>
            <div class="flex fon15">
                <div id="dsearch" class="mar23p10 flex point">
                    <i class="fas fa-search"></i>
                    <div><input type="text" placeholder="search here"></div>
                </div>
                <div class="mar23p10 flex point" onclick="open_search()">SEARCH <div id="magnifying-glass"></div></div>
                <div class="mar23p10 flex point" id="myaccount" onmouseover="myAccount()" ><div>ACCOUNT</div> <i class="far marl5p fa-user-circle"></i></div>
                <a href="./cart.html"><div class="mar23p10 flex point colwhite"><div>CART</div> <i class="fab marl5p fa-shopify"></i><div id="cartitem" class="textal">0</div></div></a>
            </div>
        </div>
    </div>
    <div id="menu3" class="width100 backwhite height53p borbot2p">
        <div class="width90 flex marauto jusspacebet">
          <div id="menucol3" class="flex">
            <button class="flex allignitcen bord " id="eyeGlass" onclick="eye()" onmouseover="eyeGlass()">Eyeglasses <div id="chevron"></div></button>
            <button class=" flex allignitcen" id="compglass" onclick="com_glass()" onmouseover="compGlass()">Computer Glasses <div id="chevron"></div></button>
            <a href="../collections/sunglass.html"><button>Sunglasses</button></a>
            <a href="../collections/contact-lenses.html"><button>Contact Lenses</button></a>
            <a href="../collections/accesories.html"><button>Accessories</button></a>
            <a href="../products/hometryon.html"><button>Home Try-On</button></a>
            <a href="../pages/stoe-locator.html"><button>Store Locator</button></a>
            <a href="../pages/franchisee.html"><button>Franchise</button></a>
            <a href="../products/lensmaker.html"><button>Lensmakers  </button></a>
          </div>
          <div>
            <img class="mar15p point" src="https://cdn.shopify.com/s/files/1/0015/2879/1092/files/3Dlogo_large.png?v=1608103908" alt="">
          </div>
        </div> 
    </div>
    <div id="menu767" class="width100 height767 bl1 colwhite borbot2p">
        <div class="width95 flex marauto jusspacebet">  
            <div onclick="revmenu()" id="threeline">
                <div id="line"></div>
                <div id="line"></div>
                <div id="line"></div>
            </div>
            <a href="./index.html"><div id="div767"><img id="img767" class="mart3" src="https://cdn.shopify.com/s/files/1/0015/2879/1092/files/SPECSMAKERS_Logo_large.png?v=1610087240" alt=""></div></a>
            <a href="./cart.html"><div id="cart" class="mar23p10 flex point"><i class="fab marl5p fa-shopify"></i><div id="cartitem" class="textal">0</div></div></a>
        </div>
    </div>
</div>

<div id="resmenu">
    <div id="resmenu_content">
        <div>
            <div id="threeline">
                <div id="line"></div>
                <div id="line"></div>
                <div id="line"></div>
            </div>
            <div id="span"></div>
        </div>
        <div id="line2">
            <div class="flex">
                <div id="magnifying-glass"></div>
                <div><input type="text" placeholder="What are you looking for?"></div>
            </div>
            <div><button>Search</button></div>
        </div>
    </div>
    <div id="menupro">
        <div>
            <div id="logsign" class="flex">
                <div><a id="black" href="./account/login.html">LOGIN</a></div>
                <div><a id="black" href="./account/login.html">REGISTER</a></div>
            </div>
            <div><a id="black" href="./account/login.html"><i class="far marl5p fa-user-circle"></i></a></div>
        </div>
        <div>
            <div class="flex">
                <div><a id="black" href="./collections/eyeglasses.html">Eyeglasses</a></div>
                <div id="chevron"></div>
            </div>
            <div><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/products/1_f04b0118-b1e6-4a12-89f3-36b6cce334f8_360x.jpg?v=1641367173" alt=""></div>
        </div>
        <div>
            <div class="flex">
                <div><a id="black" href="./collections/computer_glasses.html">Computer Glasses</a></div>
                <div id="chevron"></div>
            </div>
            <div><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/products/3_8bd9586f-2d63-4b61-b944-80fdfde0e2bb_360x.jpg?v=1609503279" alt=""></div>
        </div>
        <div>
            <div><a id="black" href="./collections/sunglass.html">Sunglasses</a></div>
            <div><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/products/P6045-3_28426c17-6bf9-4598-b87f-fffbd9db5f46_360x.jpg?v=1604041970" alt=""></div>
        </div>
        <div>
            <div><a id="black" href="./collections/contact-lenses.html">Contact Lenses</a></div>
            <div><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/products/Toric-Lens-01_f950278e-e4f1-4fbe-9574-cd4288a265f9_360x.jpg?v=1596562599" alt=""></div>
        </div>
        <div>
            <div><a id="black" href="./collections/accesories.html">Accessories</a></div>
            <div></div>
        </div>
        <div>
            <div><a id="black" href="./products/hometryon.html">Home Try-On</a></div>
            <div></div>
        </div>
        <div>
            <div><a id="black" href="./pages/stoe-locator.html">Store Locator</a></div>
            <div></div>
        </div>
        <div>
            <div><a id="black" href="./pages/franchisee.html">Franchise</a></div>
            <div></div>
        </div>
        <div>
            <div><a id="black" href="./products/lensmaker.html">Lensmakers</a></div>
            <div></div>
        </div>
    </div>
</div>


<div id="main_account">
    <div >
        <div id="acc-wrap">
            <div id="acc">
            </div>
        </div>
        <div id="acc-wrap2" class="textal">
            <div id="acc2">
                <div id="log1">Login to my account</div>
                <div><input id="email" type="email" placeholder="Email"></div>
                <div><input id="password" type="password" placeholder="*****"></div>
                <div><button onclick="loginPage()">Login</button></div>
                <div id="log2">
                    <div>New Customer? <a href="./account/login.html">CREATE YOUR ACCOUNT</a></div>
                    <div>Lost password? <a href="./account/login.html">RECOVER PASSWORD</a></div>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="glass1">
    <div id="Eyeglasses">
        <div class="flex">
            <div>
                <div>
                    <div>GENDER</div>
                    <div>Men</div>
                    <div>Women</div>
                    <div>Kids</div>
                </div>
                <div>
                    <div>SHOP BY COLLECTION</div>
                    <div>2 Pairs at ₹1000</div>
                    <div>DigiPro</div>
                    <div>Happster Acetate</div>
                    <div>Light Weight</div>
                    <div>Clip-Ons</div>
                    <div>Metallics</div>
                    <div>Lightanium</div>
                    <div>Reading Glasses</div>
                </div>
                <div>
                    <div>SHOp BY TYPE</div>
                    <div>Full Frame</div>
                    <div>Half Frame</div>
                    <div>Rimless</div>
                    <div>Reading Glasses</div>
                </div>
            </div>
            <div>
                <div>
                    <div>SHOP BY SHAPE</div>
                    <div>Pilot</div>
                    <div>Cateye</div>
                    <div>Rectangle</div>
                    <div>Round</div>
                    <div>Hexagona</div>
                </div>
            </div>
        </div>
        <div>
            <img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/t/34/assets/1610977007_0.jpg" alt="">
        </div>
    </div>
</div>


<div id="computerglass">
    <div id="Eyeglasses"  class="flex">
        <div>
           <div>
            <div>
                <div>SHOP BY COLLECTION</div>
                <div>BlueZero (Zero Power)</div>
                <div>Blupro (With Power)</div>
            </div>
            <div>
                <div>BlueZero (ZERO POWER)</div>
                <div>Pilot</div>
                <div>Cateye</div>
                <div>Rectangle</div>
                <div>Round</div>
                <div>Oval</div>
            </div>
            <div>
                <div>BlueZero (WITH POWER)</div>
                <div>Pilot</div>
                <div>Cateye</div>
                <div>Rectangle</div>
                <div>Round</div>
                <div>Oval</div>
            </div>
           </div>
        </div>
        <div class="flex">
            <div><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/t/34/assets/1610976503_0.jpg" alt=""></div>
            <div><img src="https://cdn.shopify.com/s/files/1/0015/2879/1092/t/34/assets/1610976489_0.jpg" alt=""></div>
        </div>
    </div>
</div>`
}

export default navbar